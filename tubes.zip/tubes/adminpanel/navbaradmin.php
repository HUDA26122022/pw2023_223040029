   <!-- navbar -->
    <nav class="navbar navbar-expand-lg navbar-light warna3 fixed-top position-fixed">
      <div class="container">
      <a class="navbar-brand" href="#"><img src="../img/icons/logo1.png" alt="" width="80" height="45"></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse " id="navbarNav">
          <ul class="navbar-nav">
            <li class="nav-item">
            <a class="nav-link text-white" href="../index.php"> 
                 Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link  text-white" href="kategori.php">Kategori</a>
            </li>
            <li class="nav-item">
              <a class="nav-link  text-white" href="product.php">Product</a>
            </li>
            <li class="nav-item">
              <a class="nav-link  text-white" onclick="return confirm('Apakah Anda Yakin Ingin Keluar!!');" href="logout.php">logout</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <!-- end navbar -->


    