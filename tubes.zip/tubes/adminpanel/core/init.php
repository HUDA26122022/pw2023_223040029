<?php 

session_start();


require "function/db.php";
require "function/user.php";

?>