<!-- footer -->
<footer class=" container-fluid warna3 pt-2">

  <div class="container">
    <div class="row">
    <div class="col-md-2 col-lg-3 col-x12 mx-auto mt-3">
      <h5>Pembayaran Melalui</h5>
      <div class="card-credit" >
        <img src="img/pembayaran/bri.jpg" width="60" height="50" alt="">
        <img src="img/pembayaran/dana.jpg" width="60" height="50" alt="">
      </div>
    </div>

    <div class="col-md-2 col-lg-3 col-x12 mx-auto mt-3">
      <h5 class="fw-bold">Kontak</h5>
      <p><img src="img/icons/home.png" width="20" height="20" alt=""> Tasikmalaya.Jawa Barat</p>
      <p><img src="img/icons/email.png"  width="20" height="20" alt=""> serasa@gmail.com</p>
      <p><img src="img/icons/telephone-call.png" width="20" height="20" alt=""> 082134567818</p>
    </div>

    <div class="col-md-2 col-lg-3 col-x12 mx-auto mt-3 ">
      <div class="fw-bold">Medsos</div>
      <ul class="list-unstyled list-inline me-0">
        <li class="list-inline-item br-2">
          <a href=""><img src="img/icons/instagram.png" width="20" height="20" alt=""></a>
        </li>
        <li class="list-inline-item">
          <a href=""><img src="img/icons/facebook.png" width="20" height="20"  alt=""></a>
        </li>
        <li class="list-inline-item">
          <a href=""><img src="img/icons/tik-tok.png"width="20" height="20" alt=""></a>
        </li>
      </ul>
      </div>
    </div>
  </div>
  <div class="row text-center warna4 text-white">
      <div class="col-md-12 mt-3">
        <p class="copyright">Copyright © Ahmad Mulia Huda 2023</p>
      </div>
    </div>
</footer>